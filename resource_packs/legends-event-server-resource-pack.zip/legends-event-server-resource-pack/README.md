# legends-event-server
This is a replication of the Minecraft Legends Lve Event Server made back in 2023.

I do not own any copyright rights to the Legends Live Event server as I am not the original creator, Gamemode One and Mojang Studios is.
